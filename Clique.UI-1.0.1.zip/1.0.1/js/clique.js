(function(core) {
  if (typeof define === 'function' && define.amd) {
    define('clique', function() {
      var clique;
      clique = window.Clique || core(window, window.jQuery, window.document);
      clique.load = function(res, req, onload, config) {
        var base, i, load, resource, resources;
        resources = res.split(',');
        load = [];
        base = (config.config && config.config.clique && config.config.clique.base ? config.config.clique.base : '').replace(/\/+$/g, '');
        if (!base) {
          throw new Error('Please define base path to Clique in the requirejs config.');
        }
        i = 0;
        while (i < resources.length) {
          resource = resources[i].replace(/\./g, '/');
          load.push(base + '/components/' + resource);
          i += 1;
        }
        req(load, function() {
          onload(clique);
        });
      };
      return clique;
    });
  }
  if (!window.jQuery) {
    throw new Error('Clique requires jQuery');
  }
  if (window && window.jQuery) {
    core(window, window.jQuery, window.document);
  }
})(function(global, $, doc) {
  var hovercls, hoverset, selector, _c, _cTEMP;
  _c = {};
  _cTEMP = window.Clique;
  _c.version = '1.0.1';
  _c.noConflict = function() {
    if (_cTEMP) {
      window.Clique = _cTEMP;
      $.Clique = _cTEMP;
      $.fn.clique = _cTEMP.fn;
    }
    return _c;
  };
  _c.prefix = function(str) {
    return str;
  };
  _c.$ = $;
  _c.$doc = $(document);
  _c.$win = $(window);
  _c.$html = $('html');
  _c.fn = function(command, options) {
    var args, cmd, component, method;
    args = arguments;
    cmd = command.match(/^([a-z\-]+)(?:\.([a-z]+))?/i);
    component = cmd[1];
    method = cmd[2];
    if (!method && typeof options === 'string') {
      method = options;
    }
    if (!_c[component]) {
      $.error('Clique component [' + component + '] does not exist.');
      return this;
    }
    return this.each(function() {
      var $this, data;
      $this = $(this);
      data = $this.data(component);
      if (!data) {
        $this.data(component, data = _c[component](this, (method ? void 0 : options)));
      }
      if (method) {
        data[method].apply(data, Array.prototype.slice.call(args, 1));
      }
    });
  };
  _c.support = {
    requestAnimationFrame: window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.msRequestAnimationFrame || window.oRequestAnimationFrame || function(callback) {
      setTimeout(callback, 1e3 / 60);
    },
    touch: 'ontouchstart' in window && navigator.userAgent.toLowerCase().match(/mobile|tablet/) || global.DocumentTouch && document instanceof global.DocumentTouch || global.navigator.msPointerEnabled && global.navigator.msMaxTouchPoints > 0 || global.navigator.pointerEnabled && global.navigator.maxTouchPoints > 0 || false,
    mutationobserver: global.MutationObserver || global.WebKitMutationObserver || null
  };
  _c.support.transition = (function() {
    var transitionEnd;
    transitionEnd = (function() {
      var element, name, transEndEventNames;
      element = doc.body || doc.documentElement;
      transEndEventNames = {
        WebkitTransition: 'webkitTransitionEnd',
        MozTransition: 'transitionend',
        OTransition: 'oTransitionEnd otransitionend',
        transition: 'transitionend'
      };
      for (name in transEndEventNames) {
        if (element.style[name] !== undefined) {
          return transEndEventNames[name];
        }
      }
    })();
    return transitionEnd && {
      end: transitionEnd
    };
  })();
  _c.support.animation = (function() {
    var animationEnd;
    animationEnd = (function() {
      var animEndEventNames, element, name;
      element = doc.body || doc.documentElement;
      animEndEventNames = {
        WebkitAnimation: 'webkitAnimationEnd',
        MozAnimation: 'animationend',
        OAnimation: 'oAnimationEnd oanimationend',
        animation: 'animationend'
      };
      for (name in animEndEventNames) {
        if (element.style[name] !== undefined) {
          return animEndEventNames[name];
        }
      }
    })();
    return animationEnd && {
      end: animationEnd
    };
  })();
  _c.utils = {
    now: Date.now || function() {
      return new Date().getTime();
    },
    isString: function(obj) {
      return Object.prototype.toString.call(obj) === '[object String]';
    },
    isNumber: function(obj) {
      return !isNaN(parseFloat(obj)) && isFinite(obj);
    },
    isDate: function(obj) {
      var d;
      d = new Date(obj);
      return d !== "Invalid Date" && d.toString() !== "Invalid Date" && !isNaN(d);
    },
    str2json: function(str, notevil) {
      var e, newFN;
      try {
        if (notevil) {
          return JSON.parse(str.replace(/([\$\w]+)\s* :/g, function(_, $1) {
            return '"' + $1 + '" :';
          }).replace(/'([^']+)'/g, function(_, $1) {
            return '"' + $1 + '"';
          }));
        } else {
          newFN = Function;
          return new newFN('', 'var json = ' + str + '; return JSON.parse(JSON.stringify(json));')();
        }
      } catch (_error) {
        e = _error;
        return false;
      }
    },
    debounce: function(func, wait, immediate) {
      return function() {
        var args, callNow, context, later, timeout;
        context = this;
        args = arguments;
        later = function() {
          var timeout;
          timeout = null;
          if (!immediate) {
            func.apply(context, args);
          }
        };
        callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) {
          func.apply(context, args);
        }
      };
    },
    removeCssRules: function(selectorRegEx) {
      if (!selectorRegEx) {
        return;
      }
      setTimeout(function() {
        var idx, idxs, stylesheet, _i, _j, _k, _len, _len1, _len2, _ref;
        try {
          _ref = document.styleSheets;
          _i = 0;
          _len = _ref.length;
          while (_i < _len) {
            stylesheet = _ref[_i];
            idxs = [];
            stylesheet.cssRules = stylesheet.cssRules;
            idx = _j = 0;
            _len1 = stylesheet.cssRules.length;
            while (_j < _len1) {
              if (stylesheet.cssRules[idx].type === CSSRule.STYLE_RULE && selectorRegEx.test(stylesheet.cssRules[idx].selectorText)) {
                idxs.unshift(idx);
              }
              idx = ++_j;
            }
            _k = 0;
            _len2 = idxs.length;
            while (_k < _len2) {
              stylesheet.deleteRule(idxs[_k]);
              _k++;
            }
            _i++;
          }
        } catch (_error) {}
      }, 0);
    },
    isInView: function(element, options) {
      var $element, left, offset, top, window_left, window_top;
      $element = $(element);
      if (!$element.is(':visible')) {
        return false;
      }
      window_left = _c.$win.scrollLeft();
      window_top = _c.$win.scrollTop();
      offset = $element.offset();
      left = offset.left;
      top = offset.top;
      options = $.extend({
        topoffset: 0,
        leftoffset: 0
      }, options);
      if (top + $element.height() >= window_top && top - options.topoffset <= window_top + _c.$win.height() && left + $element.width() >= window_left && left - options.leftoffset <= window_left + _c.$win.width()) {
        return true;
      } else {
        return false;
      }
    },
    checkDisplay: function(context, initanimation) {
      var elements;
      elements = $('[data-margin], [data-row-match], [data-row-margin], [data-check-display]', context || document);
      if (context && !elements.length) {
        elements = $(context);
      }
      elements.trigger('display.clique.check');
      if (initanimation) {
        if (typeof initanimation !== 'string') {
          initanimation = '[class*="animation-"]';
        }
        elements.find(initanimation).each(function() {
          var anim, cls, ele;
          ele = $(this);
          cls = ele.attr('class');
          anim = cls.match(/animation\-(.+)/);
          ele.removeClass(anim[0]).width();
          ele.addClass(anim[0]);
        });
      }
      return elements;
    },
    options: function(string) {
      var options, start;
      if ($.isPlainObject(string)) {
        return string;
      }
      start = string ? string.indexOf('{') : -1;
      options = {};
      if (start !== -1) {
        try {
          options = _c.utils.str2json(string.substr(start));
        } catch (_error) {}
      }
      return options;
    },
    animate: function(element, cls) {
      var d;
      d = $.Deferred();
      element = $(element);
      cls = cls;
      element.css('display', 'none').addClass(cls).one(_c.support.animation.end, function() {
        element.removeClass(cls);
        d.resolve();
      }).width();
      element.css({
        display: ''
      });
      return d.promise();
    },
    uid: function(prefix) {
      return (prefix || 'id') + _c.utils.now() + 'RAND' + Math.ceil(Math.random() * 1e5);
    },
    template: function(str, data) {
      var cmd, fn, i, newFN, openblocks, output, prop, toc, tokens;
      tokens = str.replace(/\n/g, "\\n").replace(/\{\{\{\s*(.+?)\s*\}\}\}/g, "{{!$1}}").split(/(\{\{\s*(.+?)\s*\}\})/g);
      i = 0;
      output = [];
      openblocks = 0;
      while (i < tokens.length) {
        toc = tokens[i];
        if (toc.match(/\{\{\s*(.+?)\s*\}\}/)) {
          i = i + 1;
          toc = tokens[i];
          cmd = toc[0];
          prop = toc.substring((toc.match(/^(\^|\#|\!|\~|\:)/) ? 1 : 0));
          switch (cmd) {
            case '~':
              output.push('for(var $i = 0; $i < ' + prop + '.length; $i++) { var $item = ' + prop + '[$i];');
              openblocks++;
              break;
            case ':':
              output.push('for(var $key in ' + prop + ') { var $val = ' + prop + '[$key];');
              openblocks++;
              break;
            case '#':
              output.push('if(' + prop + ') {');
              openblocks++;
              break;
            case '^':
              output.push('if(!' + prop + ') {');
              openblocks++;
              break;
            case '/':
              output.push('}');
              openblocks--;
              break;
            case '!':
              output.push('__ret.push(' + prop + ');');
              break;
            default:
              output.push('__ret.push(escape(' + prop + '));');
          }
        } else {
          output.push('__ret.push(\'' + toc.replace(/\'/g, '\\\'') + '\');');
        }
        i = i + 1;
      }
      newFN = Function;
      fn = new newFN("$data", ["var __ret = [];", "try {", "with($data){", !openblocks ? output.join("") : '__ret = ["Not all blocks are closed correctly."]', "};", "}catch(e){__ret = [e.message];}", 'return __ret.join("").replace(/\\n\\n/g, "\\n");', "function escape(html) { return String(html).replace(/&/g, '&amp;').replace(/\"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');}"].join("\n"));
      if (data) {
        return fn(data);
      } else {
        return fn;
      }
    },
    events: {
      click: _c.support.touch ? 'tap' : 'click'
    }
  };
  window.Clique = _c;
  $.Clique = _c;
  $.fn.clique = _c.fn;
  _c.langdirection = _c.$html.attr('dir') === 'rtl' ? 'right' : 'left';
  _c.components = {};
  _c.component = function(name, def) {
    var fn;
    fn = function(element, options) {
      var $this;
      $this = this;
      this.Clique = _c;
      this.element = element ? $(element) : null;
      this.options = $.extend(true, {}, this.defaults, options);
      this.plugins = {};
      if (this.element) {
        this.element.data('clique.data.' + name, this);
      }
      this.init();
      (this.options.plugins.length ? this.options.plugins : Object.keys(fn.plugins)).forEach(function(plugin) {
        if (fn.plugins[plugin].init) {
          fn.plugins[plugin].init($this);
          $this.plugins[plugin] = true;
        }
      });
      this.trigger('init.clique.component', [name, this]);
      return this;
    };
    fn.plugins = {};
    $.extend(true, fn.prototype, {
      defaults: {
        plugins: []
      },
      boot: function() {},
      init: function() {},
      on: function(a1, a2, a3) {
        return $(this.element || this).on(a1, a2, a3);
      },
      one: function(a1, a2, a3) {
        return $(this.element || this).one(a1, a2, a3);
      },
      off: function(evt) {
        return $(this.element || this).off(evt);
      },
      trigger: function(evt, params) {
        return $(this.element || this).trigger(evt, params);
      },
      find: function(selector) {
        return $((this.element ? this.element : [])).find(selector);
      },
      proxy: function(obj, methods) {
        var $this;
        $this = this;
        methods.split(' ').forEach(function(method) {
          if (!$this[method]) {
            $this[method] = function() {
              return obj[method].apply(obj, arguments);
            };
          }
        });
      },
      mixin: function(obj, methods) {
        var $this;
        $this = this;
        methods.split(' ').forEach(function(method) {
          if (!$this[method]) {
            $this[method] = obj[method].bind($this);
          }
        });
      },
      option: function() {
        if (arguments.length === 1) {
          return this.options[arguments[0]] || undefined;
        } else {
          if (arguments.length === 2) {
            this.options[arguments[0]] = arguments[1];
          }
        }
      }
    }, def);
    this.components[name] = fn;
    this[name] = function() {
      var element, options;
      if (arguments.length) {
        switch (arguments.length) {
          case 1:
            if (typeof arguments[0] === 'string' || arguments[0].nodeType || arguments[0] instanceof jQuery) {
              element = $(arguments[0]);
            } else {
              options = arguments[0];
            }
            break;
          case 2:
            element = $(arguments[0]);
            options = arguments[1];
        }
      }
      if (element && element.data('clique.data.' + name)) {
        return element.data('clique.data.' + name);
      }
      return new _c.components[name](element, options);
    };
    if (_c.domready) {
      _c.component.boot(name);
    }
    return fn;
  };
  _c.plugin = function(component, name, def) {
    this.components[component].plugins[name] = def;
  };
  _c.component.boot = function(name) {
    if (_c.components[name].prototype && _c.components[name].prototype.boot && !_c.components[name].booted) {
      _c.components[name].prototype.boot.apply(_c, []);
      _c.components[name].booted = true;
    }
  };
  _c.component.bootComponents = function() {
    var component;
    for (component in _c.components) {
      _c.component.boot(component);
    }
  };
  _c.domObservers = [];
  _c.domready = false;
  _c.ready = function(fn) {
    _c.domObservers.push(fn);
    if (_c.domready) {
      fn(document);
    }
  };
  _c.on = function(a1, a2, a3) {
    if (a1 && a1.indexOf('ready.clique.dom') > -1 && _c.domready) {
      a2.apply(_c.$doc);
    }
    return _c.$doc.on(a1, a2, a3);
  };
  _c.one = function(a1, a2, a3) {
    if (a1 && a1.indexOf('ready.clique.dom') > -1 && _c.domready) {
      a2.apply(_c.$doc);
      return _c.$doc;
    }
    return _c.$doc.one(a1, a2, a3);
  };
  _c.trigger = function(evt, params) {
    return _c.$doc.trigger(evt, params);
  };
  _c.domObserve = function(selector, fn) {
    if (!_c.support.mutationobserver) {
      return;
    }
    fn = fn || function() {};
    $(selector).each(function() {
      var $element, element, observer;
      element = this;
      $element = $(element);
      if ($element.data('observer')) {
        return;
      }
      try {
        observer = new _c.support.mutationobserver(_c.utils.debounce(function(mutations) {
          fn.apply(element, []);
          $element.trigger('changed.clique.dom');
        }, 50));
        observer.observe(element, {
          childList: true,
          subtree: true
        });
        $element.data('observer', observer);
      } catch (_error) {}
    });
  };
  _c.delay = function(fn, timeout, args) {
    if (timeout == null) {
      timeout = 0;
    }
    fn = fn || function() {};
    return setTimeout(function() {
      return fn.apply(null, args);
    }, timeout);
  };
  _c.on('domready.clique.dom', function() {
    _c.domObservers.forEach(function(fn) {
      fn(document);
    });
    if (_c.domready) {
      _c.utils.checkDisplay(document);
    }
  });
  $(function() {
    _c.$body = $('body');
    _c.ready(function(context) {
      _c.domObserve('[data-observe]');
    });
    _c.on('changed.clique.dom', function(e) {
      var ele;
      ele = e.target;
      _c.domObservers.forEach(function(fn) {
        fn(ele);
      });
      _c.utils.checkDisplay(ele);
    });
    _c.trigger('beforeready.clique.dom');
    _c.component.bootComponents();
    setInterval((function() {
      var fn, memory;
      memory = {
        x: window.pageXOffset,
        y: window.pageYOffset
      };
      fn = function() {
        var dir;
        if (memory.x !== window.pageXOffset || memory.y !== window.pageYOffset) {
          dir = {
            x: 0,
            y: 0
          };
          if (window.pageXOffset !== memory.x) {
            dir.x = (window.pageXOffset > memory.x ? 1 : -1);
          }
          if (window.pageYOffset !== memory.y) {
            dir.y = (window.pageYOffset > memory.y ? 1 : -1);
          }
          memory = {
            dir: dir,
            x: window.pageXOffset,
            y: window.pageYOffset
          };
          _c.$doc.trigger('scrolling.clique.dom', [memory]);
        }
      };
      if (_c.support.touch) {
        _c.$html.on('touchmove touchend MSPointerMove MSPointerUp pointermove pointerup', fn);
      }
      if (memory.x || memory.y) {
        fn();
      }
      return fn;
    })(), 15);
    _c.trigger('domready.clique.dom');
    if (_c.support.touch) {
      if (navigator.userAgent.match(/(iPad|iPhone|iPod)/g)) {
        _c.$win.on('load orientationchange resize', _c.utils.debounce((function() {
          var fn;
          fn = function() {
            $('.height-viewport').css('height', window.innerHeight);
            return fn;
          };
          return fn();
        })(), 100));
      }
    }
    _c.trigger('afterready.clique.dom');
    _c.domready = true;
  });
  if (_c.support.touch) {
    hoverset = false;
    hovercls = 'hover';
    selector = '.overlay, .overlay-hover, .overlay-toggle, .animation-hover, .has-hover';
    _c.$html.on('touchstart MSPointerDown pointerdown', selector, function() {
      if (hoverset) {
        $('.' + hovercls).removeClass(hovercls);
      }
      hoverset = $(this).addClass(hovercls);
    }).on('touchend MSPointerUp pointerup', function(e) {
      var exclude;
      exclude = $(e.target).parents(selector);
      if (hoverset) {
        hoverset.not(exclude).removeClass(hovercls);
      }
    });
  }
  $.expr[':'].on = function(obj) {
    return $(obj).prop('on');
  };
  return _c;
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-events', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.events requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, dispatch, evt, k, v, _ref;
  $ = _c.$;
  dispatch = $.event.dispatch || $.event.handle;
  _c.events = {};
  _c.events.scrollstart = {
    setup: function(data) {
      var handler, timer, uid, _data;
      uid = _c.utils.uid('scrollstart');
      $(this).data('clique.event.scrollstart.uid', uid);
      _data = $.extend({
        latency: $.event.special.scrollstop.latency
      }, data);
      timer = null;
      handler = function(e) {
        var _args, _self;
        _self = this;
        _args = arguments;
        if (timer) {
          clearTimeout(timer);
        } else {
          e.type = 'scrollstart.clique.dom';
          $(e.target).trigger('scrollstart.clique.dom', e);
        }
        timer = setTimeout(function() {
          timer = null;
        }, _data.latency);
      };
      return $(this).on('scroll', _c.utils.debounce(handler, 100)).data(uid, handler);
    },
    teardown: function() {
      var uid;
      uid = $(this).data('clique.event.scrollstart.uid');
      $(this).off('scroll', $(this).data(uid));
      $(this).removeData(uid);
      return $(this).removeData('clique.event.scrollstart.uid');
    }
  };
  _c.events.scrollstop = {
    latency: 150,
    setup: function(data) {
      var handler, timer, uid, _data;
      uid = _c.utils.uid('scrollstop');
      $(this).data('clique.event.scrolltop.uid', uid);
      _data = $.extend({
        latency: $.event.special.scrollstop.latency
      }, data);
      timer = null;
      handler = function(e) {
        var _args, _self;
        _self = this;
        _args = arguments;
        if (timer) {
          clearTimeout(timer);
        }
        timer = setTimeout(function() {
          timer = null;
          e.type = 'scrollstop.clique.dom';
          $(e.target).trigger('scrollstop.clique.dom', e);
        }, _data.latency);
      };
      $(this).on('scroll', _c.utils.debounce(handler, 100)).data(uid, handler);
    },
    teardown: function() {
      var uid;
      uid = $(this).data('clique.event.scrolltop.uid');
      $(this).off('scroll', $(this).data(uid));
      $(this).removeData(uid);
      return $(this).removeData('clique.event.scrolltop.uid');
    }
  };
  _c.events.resizeend = {
    latency: 250,
    setup: function(data) {
      var handler, timer, uid, _data;
      uid = _c.utils.uid('resizeend');
      $(this).data('clique.event.resizeend.uid', uid);
      _data = $.extend({
        latency: $.event.special.resizeend.latency
      }, data);
      timer = _data;
      handler = function(e) {
        var _args, _self;
        _self = this;
        _args = arguments;
        if (timer) {
          clearTimeout(timer);
        }
        timer = setTimeout(function() {
          timer = null;
          e.type = 'resizeend.clique.dom';
          return $(e.target).trigger('resizeend.clique.dom', e);
        }, _data.latency);
      };
      return $(this).on('resize', _c.utils.debounce(handler, 100)).data(uid, handler);
    },
    teardown: function() {
      var uid;
      uid = $(this).data('clique.event.resizeend.uid');
      $(this).off('resize', $(this).data(uid));
      $(this).removeData(uid);
      return $(this).removeData('clique.event.resizeend.uid');
    }
  };
  evt = function(fn) {
    if (fn) {
      return this.on(k, fn);
    } else {
      return this.trigger(k);
    }
  };
  _ref = _c.events;
  for (k in _ref) {
    v = _ref[k];
    if (typeof v === 'object') {
      $.event.special[k] = v;
      $.fn[k] = evt;
    }
  }
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-browser', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.browser requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $;
  $ = _c.$;
  return _c.component('browser', {
    defaults: {
      addClasses: true,
      detectDevice: true,
      detectScreen: true,
      detectOS: true,
      detectBrowser: true,
      detectLanguage: true,
      detectPlugins: true,
      detectSupport: ['flex', 'animation']
    },
    device: {
      type: '',
      model: '',
      orientation: ''
    },
    browser: {
      engine: '',
      major: '',
      minor: '',
      name: '',
      patch: '',
      version: ''
    },
    screen: {
      size: '',
      touch: false
    },
    deviceTypes: ['tv', 'tablet', 'mobile', 'desktop'],
    screens: {
      mini: 0,
      small: 480,
      medium: 768,
      large: 960,
      xlarge: 1220
    },
    browserLanguage: {
      direction: '',
      code: ''
    },
    boot: function() {
      return _c.ready(function(context) {
        var ele, obj;
        ele = _c.$doc;
        if (!ele.data('clique.data.browser')) {
          obj = _c.browser(ele);
        }
      });
    },
    init: function() {
      this.getProperties();
      return _c.$win.on('resize orientationchange', _c.utils.debounce((function(_this) {
        return function() {
          return _this.getProperties();
        };
      })(this), 250));
    },
    getProperties: function() {
      var win;
      win = _c.$win[0];
      this.userAgent = (win.navigator.userAgent || win.navigator.vendor || win.opera).toLowerCase();
      if (!!this.options.detectDevice) {
        this.detectDevice();
      }
      if (!!this.options.detectScreen) {
        this.detectScreen();
      }
      if (!!this.options.detectOS) {
        this.detectOS();
      }
      if (!!this.options.detectBrowser) {
        this.detectBrowser();
      }
      if (!!this.options.detectPlugins) {
        this.detectPlugins();
      }
      if (!!this.options.detectLanguage) {
        this.detectLanguage();
      }
      if (!!this.options.detectSupport) {
        this.detectSupport();
      }
      return setTimeout((function(_this) {
        return function() {
          if (_this.options.addClasses) {
            _this.addClasses();
          }
          return _this.trigger('updated.browser.clique');
        };
      })(this), 0);
    },
    test: function(rgx) {
      return rgx.test(this.userAgent);
    },
    exec: function(rgx) {
      return rgx.exec(this.userAgent);
    },
    uamatches: function(key) {
      return this.userAgent.indexOf(key) > -1;
    },
    version: function(versionType, versionFull) {
      var versionArray;
      versionType.version = versionFull;
      versionArray = versionFull.split('.');
      if (versionArray.length > 0) {
        versionArray = versionArray.reverse();
        versionType.major = versionArray.pop();
        if (versionArray.length > 0) {
          versionType.minor = versionArray.pop();
          if (versionArray.length > 0) {
            versionArray = versionArray.reverse();
            versionType.patch = versionArray.join('.');
          } else {
            versionType.patch = '0';
          }
        } else {
          versionType.minor = '0';
        }
      } else {
        versionType.major = '0';
      }
    },
    detectDevice: function() {
      var device, h, w;
      device = this.device;
      if (this.test(/googletv|smarttv|smart-tv|internet.tv|netcast|nettv|appletv|boxee|kylo|roku|dlnadoc|roku|pov_tv|hbbtv|ce\-html/)) {
        device.type = this.deviceTypes[0];
        device.model = 'smarttv';
      } else if (this.test(/xbox|playstation.3|wii/)) {
        device.type = this.deviceTypes[0];
        device.model = 'console';
      } else if (this.test(/ip(a|ro)d/)) {
        device.type = this.deviceTypes[1];
        device.model = 'ipad';
      } else if ((this.test(/tablet/) && !this.test(/rx-34/)) || this.test(/folio/)) {
        device.type = this.deviceTypes[1];
        device.model = String(this.exec(/playbook/) || '');
      } else if (this.test(/linux/) && this.test(/android/) && !this.test(/fennec|mobi|htc.magic|htcX06ht|nexus.one|sc-02b|fone.945/)) {
        device.type = this.deviceTypes[1];
        device.model = 'android';
      } else if (this.test(/kindle/) || (this.test(/mac.os/) && this.test(/silk/))) {
        device.type = this.deviceTypes[1];
        device.model = 'kindle';
      } else if (this.test(/gt-p10|sc-01c|shw-m180s|sgh-t849|sch-i800|shw-m180l|sph-p100|sgh-i987|zt180|htc(.flyer|\_flyer)|sprint.atp51|viewpad7|pandigital(sprnova|nova)|ideos.s7|dell.streak.7|advent.vega|a101it|a70bht|mid7015|next2|nook/) || (this.test(/mb511/) && this.test(/rutem/))) {
        device.type = this.deviceTypes[1];
        device.model = 'android';
      } else if (this.test(/bb10/)) {
        device.type = this.deviceTypes[1];
        device.model = 'blackberry';
      } else {
        device.model = this.exec(/iphone|ipod|android|blackberry|opera mini|opera mobi|skyfire|maemo|windows phone|palm|iemobile|symbian|symbianos|fennec|j2me/);
        if (device.model !== null) {
          device.type = this.deviceTypes[2];
          device.model = String(device.model);
        } else {
          device.model = '';
          if (this.test(/bolt|fennec|iris|maemo|minimo|mobi|mowser|netfront|novarra|prism|rx-34|skyfire|tear|xv6875|xv6975|google.wireless.transcoder/)) {
            device.type = this.deviceTypes[2];
          } else if (this.test(/opera/) && this.test(/windows.nt.5/) && this.test(/htc|xda|mini|vario|samsung\-gt\-i8000|samsung\-sgh\-i9/)) {
            device.type = this.deviceTypes[2];
          } else if ((this.test(/windows.(nt|xp|me|9)/) && !this.test(/phone/)) || this.test(/win(9|.9|nt)/) || this.test(/\(windows 8\)/)) {
            device.type = this.deviceTypes[3];
          } else if (this.test(/macintosh|powerpc/) && !this.test(/silk/)) {
            device.type = this.deviceTypes[3];
            device.model = 'mac';
          } else if (this.test(/linux/) && this.test(/x11/)) {
            device.type = this.deviceTypes[3];
          } else if (this.test(/solaris|sunos|bsd/)) {
            device.type = this.deviceTypes[3];
          } else if (this.test(/cros/)) {
            device.type = this.deviceTypes[3];
          } else if (this.test(/bot|crawler|spider|yahoo|ia_archiver|covario-ids|findlinks|dataparksearch|larbin|mediapartners-google|ng-search|snappy|teoma|jeeves|tineye/) && !this.test(/mobile/)) {
            device.type = this.deviceTypes[3];
            device.model = 'crawler';
          } else {
            device.type = this.deviceTypes[3];
          }
        }
      }
      if (device.type !== 'desktop' && device.type !== 'tv') {
        w = _c.$win.outerWidth();
        h = _c.$win.outerHeight();
        device.orientation = 'landscape';
        if (h > w) {
          device.orientation = 'portrait';
        }
      }
      this.device = device;
    },
    detectScreen: function() {
      var k, v, w, _ref;
      w = _c.$win.width();
      _ref = this.screens;
      for (k in _ref) {
        v = _ref[k];
        if (w > (v - 1)) {
          this.screen.size = k;
        }
      }
      this.detectTouch();
    },
    detectTouch: function() {
      var doc, touch, win;
      win = _c.$win[0];
      doc = _c.$doc[0];
      touch = 'ontouchstart' in win && win.navigator.userAgent.toLowerCase().match(/mobile|tablet/) || win.DocumentTouch && doc instanceof win.DocumentTouch || win.navigator.msPointerEnabled && win.navigator.msMaxTouchPoints > 0 || win.navigator.pointerEnabled && win.navigator.maxTouchPoints > 0 || false;
      this.screen.touch = !!touch;
    },
    detectOS: function() {
      var device, os;
      device = this.device;
      os = {};
      if (device.model !== '') {
        if (device.model === 'ipad' || device.model === 'iphone' || device.model === 'ipod') {
          os.name = 'ios';
          this.version(os, (this.test(/os\s([\d_]+)/) ? RegExp.$1 : '').replace(/_/g, '.'));
        } else if (device.model === 'android') {
          os.name = 'android';
          this.version(os, (this.test(/android\s([\d\.]+)/) ? RegExp.$1 : ''));
        } else if (device.model === 'blackberry') {
          os.name = 'blackberry';
          this.version(os, (this.test(/version\/([^\s]+)/) ? RegExp.$1 : ''));
        } else if (device.model === 'playbook') {
          os.name = 'blackberry';
          this.version(os, (this.test(/os ([^\s]+)/) ? RegExp.$1.replace(';', '') : ''));
        }
      }
      if (!os.name) {
        if (this.uamatches('win') || this.uamatches('16bit')) {
          os.name = 'windows';
          if (this.uamatches('windows nt 6.3')) {
            this.version(os, '8.1');
          } else if (this.uamatches('windows nt 6.2') || this.test(/\(windows 8\)/)) {
            this.version(os, '8');
          } else if (this.uamatches('windows nt 6.1')) {
            this.version(os, '7');
          } else if (this.uamatches('windows nt 6.0')) {
            this.version(os, 'vista');
          } else if (this.uamatches('windows nt 5.2') || this.uamatches('windows nt 5.1') || this.uamatches('windows xp')) {
            this.version(os, 'xp');
          } else if (this.uamatches('windows nt 5.0') || this.uamatches('windows 2000')) {
            this.version(os, '2k');
          } else if (this.uamatches('winnt') || this.uamatches('windows nt')) {
            this.version(os, 'nt');
          } else if (this.uamatches('win98') || this.uamatches('windows 98')) {
            this.version(os, '98');
          } else {
            if (this.uamatches('win95') || this.uamatches('windows 95')) {
              this.version(os, '95');
            }
          }
        } else if (this.uamatches('mac') || this.uamatches('darwin')) {
          os.name = 'mac os';
          if (this.uamatches('68k') || this.uamatches('68000')) {
            this.version(os, '68k');
          } else if (this.uamatches('ppc') || this.uamatches('powerpc')) {
            this.version(os, 'ppc');
          } else {
            if (this.uamatches('os x')) {
              this.version(os, (this.test(/os\sx\s([\d_]+)/) ? RegExp.$1 : 'os x').replace(/_/g, '.'));
            }
          }
        } else if (this.uamatches('webtv')) {
          os.name = 'webtv';
        } else if (this.uamatches('x11') || this.uamatches('inux')) {
          os.name = 'linux';
        } else if (this.uamatches('sunos')) {
          os.name = 'sun';
        } else if (this.uamatches('irix')) {
          os.name = 'irix';
        } else if (this.uamatches('freebsd')) {
          os.name = 'freebsd';
        } else {
          if (this.uamatches('bsd')) {
            os.name = 'bsd';
          }
        }
      }
      if (this.test(/\sx64|\sx86|\swin64|\swow64|\samd64/)) {
        os.addressRegisterSize = '64bit';
      } else {
        os.addressRegisterSize = '32bit';
      }
      this.operatingSystem = os;
    },
    detectBrowser: function() {
      var browser;
      browser = {};
      if (!this.test(/opera|webtv/) && (this.test(/msie\s([\d\w\.]+)/) || this.uamatches('trident'))) {
        browser.engine = 'trident';
        browser.name = 'ie';
        if (!window.addEventListener && document.documentMode && document.documentMode === 7) {
          this.version(browser, '8.compat');
        } else if (this.test(/trident.*rv[ :](\d+)\./)) {
          this.version(browser, RegExp.$1);
        } else {
          this.version(browser, (this.test(/trident\/4\.0/) ? '8' : RegExp.$1));
        }
      } else if (this.uamatches('firefox')) {
        browser.engine = 'gecko';
        browser.name = 'firefox';
        this.version(browser, (this.test(/firefox\/([\d\w\.]+)/) ? RegExp.$1 : ''));
      } else if (this.uamatches('gecko/')) {
        browser.engine = 'gecko';
      } else if (this.uamatches('opera') || this.uamatches('opr')) {
        browser.name = 'opera';
        browser.engine = 'presto';
        this.version(browser, (this.test(/version\/([\d\.]+)/) ? RegExp.$1 : (this.test(/opera(\s|\/)([\d\.]+)/) ? RegExp.$2 : '')));
      } else if (this.uamatches('konqueror')) {
        browser.name = 'konqueror';
      } else if (this.uamatches('chrome')) {
        browser.engine = 'webkit';
        browser.name = 'chrome';
        this.version(browser, (this.test(/chrome\/([\d\.]+)/) ? RegExp.$1 : ''));
      } else if (this.uamatches('iron')) {
        browser.engine = 'webkit';
        browser.name = 'iron';
      } else if (this.uamatches('crios')) {
        browser.name = 'chrome';
        browser.engine = 'webkit';
        this.version(browser, (this.test(/crios\/([\d\.]+)/) ? RegExp.$1 : ''));
      } else if (this.uamatches('applewebkit/')) {
        browser.name = 'safari';
        browser.engine = 'webkit';
        this.version(browser, (this.test(/version\/([\d\.]+)/) ? RegExp.$1 : ''));
      } else {
        if (this.uamatches('mozilla/')) {
          browser.engine = 'gecko';
        }
      }
      this.browser = browser;
    },
    detectLanguage: function() {
      var body, win;
      body = _c.$body[0];
      win = _c.$win[0];
      this.browserLanguage.direction = win.getComputedStyle(body).direction || 'ltr';
      this.browserLanguage.code = win.navigator.userLanguage || win.navigator.language;
    },
    detectPlugins: function() {
      var plugin, _i, _len, _ref, _results;
      this.plugins = [];
      if (typeof window.navigator.plugins !== 'undefined') {
        _ref = window.navigator.plugins;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          plugin = _ref[_i];
          _results.push(this.plugins.push(plugin.name));
        }
        return _results;
      }
    },
    detectSupport: function() {
      var check, supports, _i, _len, _ref;
      supports = (function() {
        var div, vendors;
        div = _c.$doc[0].createElement('div');
        vendors = 'Khtml Ms ms O Moz Webkit'.split(' ');
        return function(prop) {
          var vendor, _i, _len;
          if (typeof div.style[prop] !== 'undefined') {
            return true;
          }
          prop = prop.replace(/^[a-z]/, function(val) {
            return val.toUpperCase();
          });
          for (_i = 0, _len = vendors.length; _i < _len; _i++) {
            vendor = vendors[_i];
            if (typeof div.style[vendor + prop] !== 'undefined') {
              return true;
            }
          }
          return false;
        };
      })();
      if (!this.css) {
        this.css = {};
      }
      _ref = this.options.detectSupport;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        check = _ref[_i];
        this.css[check] = supports(check);
        return;
      }
    },
    addClasses: function() {
      var k, modelClass, nameClass, orientationClass, sizeClass, supportClass, touchClass, typeClass, v, _ref;
      this.removeClasses();
      if (this.browser.name) {
        nameClass = this.browser.name;
        if (nameClass === 'ie') {
          nameClass += " ie" + this.browser.major;
        }
        this.classes.push(nameClass);
        _c.$html.addClass(nameClass);
      }
      if (this.device.type) {
        typeClass = this.device.type;
        this.classes.push(typeClass);
        _c.$html.addClass(typeClass);
      }
      if (this.device.model) {
        modelClass = this.device.model;
        this.classes.push(modelClass);
        _c.$html.addClass(modelClass);
      }
      if (this.device.orientation) {
        orientationClass = this.device.orientation;
        this.classes.push(orientationClass);
        _c.$html.addClass(orientationClass);
      }
      if (this.screen.size) {
        sizeClass = "screen-" + this.screen.size;
        this.classes.push(sizeClass);
        _c.$html.addClass(sizeClass);
      }
      _ref = this.css;
      for (k in _ref) {
        v = _ref[k];
        if (!v) {
          supportClass = "no" + k;
          this.classes.push(supportClass);
          _c.$html.addClass(supportClass);
        }
      }
      touchClass = this.screen.touch ? 'touch' : 'notouch';
      this.classes.push(touchClass);
      _c.$html.addClass(touchClass);
      if (this.browserLanguage.direction) {
        _c.$html.attr('dir', this.browserLanguage.direction);
      }
      if (this.browserLanguage.code) {
        return _c.$html.attr('lang', this.browserLanguage.code);
      }
    },
    removeClasses: function() {
      if (!this.classes) {
        this.classes = [];
      }
      $.each(this.classes, function(idx, selector) {
        return _c.$html.removeClass(selector);
      });
      this.classes = [];
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-utility', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.utility requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, stacks;
  $ = _c.$;
  stacks = [];
  _c.component('stackMargin', {
    defaults: {
      cls: 'margin-small-top'
    },
    boot: function() {
      return _c.ready(function(context) {
        return $('[data-margin]', context).each(function() {
          var ele, obj;
          ele = $(this);
          if (!ele.data('clique.data.stackMargin')) {
            obj = _c.stackMargin(ele, _c.utils.options(ele.attr('data-margin')));
          }
        });
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.columns = this.element.children();
      if (!this.columns.length) {
        return;
      }
      _c.$win.on('resize orientationchange', (function() {
        var fn;
        fn = function() {
          return $this.process();
        };
        _c.$(function() {
          fn();
          return _c.$win.on('load', fn);
        });
        return _c.utils.debounce(fn, 20);
      })());
      _c.$html.on('changed.clique.dom', function(e) {
        $this.columns = $this.element.children();
        return $this.process();
      });
      this.on('display.clique.check', (function(_this) {
        return function(e) {
          $this.columns = $this.element.children();
          if (_this.element.is(':visible')) {
            return _this.process();
          }
        };
      })(this));
      return stacks.push(this);
    },
    process: function() {
      _c.utils.stackMargin(this.columns, this.options);
      return this;
    },
    revert: function() {
      this.columns.removeClass(this.options.cls);
      return this;
    }
  });
  _c.ready((function() {
    var check, iframes;
    iframes = [];
    check = function() {
      return iframes.forEach(function(iframe) {
        var height, iwidth, ratio, width;
        if (!iframe.is(':visible')) {
          return;
        }
        width = iframe.parent().width();
        iwidth = iframe.data('width');
        ratio = width / iwidth;
        height = Math.floor(ratio * iframe.data('height'));
        return iframe.css({
          height: width < iwidth ? height : iframe.data('height')
        });
      });
    };
    _c.$win.on('resize', _c.utils.debounce(check, 15));
    return function(context) {
      $('iframe.responsive-width', context).each(function() {
        var iframe;
        iframe = $(this);
        if (!iframe.data('responsive') && iframe.attr('width') && iframe.attr('height')) {
          iframe.data('width', iframe.attr('width'));
          iframe.data('height', iframe.attr('height'));
          iframe.data('responsive', true);
          return iframes.push(iframe);
        }
      });
      return check();
    };
  })());
  _c.utils.stackMargin = function(elements, options) {
    var firstvisible, offset, skip;
    options = _c.$.extend({
      cls: 'margin-small-top'
    }, options);
    options.cls = options.cls;
    elements = $(elements).removeClass(options.cls);
    skip = false;
    firstvisible = elements.filter(':visible:first');
    offset = firstvisible.length ? firstvisible.position().top + firstvisible.outerHeight() - 1 : false;
    if (offset === false) {
      return;
    }
    return elements.each(function() {
      var column;
      column = $(this);
      if (column.is(':visible')) {
        if (skip) {
          return column.addClass(options.cls);
        } else {
          if (column.position().top >= offset) {
            skip = column.addClass(options.cls);
          }
        }
      }
    });
  };
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-smoothScroll', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.smoothScroll requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, listenForScroll, scrollToElement;
  $ = _c.$;
  listenForScroll = function() {
    return _c.$win.on('mousewheel', function() {
      return $('html, body').stop(true);
    });
  };
  scrollToElement = function(ele, options) {
    var docheight, target, winheight;
    options = _c.$.extend({
      duration: 1e3,
      transition: 'easeOutExpo',
      offset: 0,
      complete: function() {}
    }, options);
    target = ele.offset().top - options.offset;
    docheight = _c.$doc.height();
    winheight = window.innerHeight;
    if (target + winheight > docheight) {
      target = docheight - winheight;
    }
    listenForScroll();
    return $('html, body').stop().animate({
      scrollTop: target
    }, options.duration, options.transition).promise().done(function() {
      options.complete();
      $('html, body').trigger('didscroll.clique.smooth-scroll');
      return _c.$win.off('mousewheel');
    });
  };
  _c.component('smoothScroll', {
    boot: function() {
      return _c.$html.on('click.smooth-scroll.clique', '[data-smooth-scroll]', function(e) {
        var ele, obj;
        e.preventDefault();
        ele = $(this);
        if (!ele.data('clique.data.smoothScroll')) {
          obj = _c.smoothScroll(ele, _c.utils.options(ele.attr('data-smooth-scroll')));
          return ele.trigger('click');
        }
      });
    },
    init: function() {
      var $this;
      $this = this;
      return this.on('click', function(e) {
        e.preventDefault();
        $('html, body').trigger('willscroll.clique.smooth-scroll');
        return scrollToElement(($(this.hash).length ? $(this.hash) : _c.$('body')), $this.options);
      });
    }
  });
  _c.utils.scrollToElement = scrollToElement;
  if (!_c.$.easing.easeOutExpo) {
    _c.$.easing.easeOutExpo = function(x, t, b, c, d) {
      if (t === d) {
        return b + c;
      } else {
        return c * (-Math.pow(2, -10 * t / d) + 1) + b;
      }
    };
  }
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-scrollspy', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.scrollspy requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, $doc, $win, checkScrollSpy, checkScrollSpyNavs, scrollspies, scrollspynavs;
  $ = _c.$;
  $win = _c.$win;
  $doc = _c.$doc;
  scrollspies = [];
  checkScrollSpy = function() {
    var i, _results;
    i = 0;
    _results = [];
    while (i < scrollspies.length) {
      _c.support.requestAnimationFrame.apply(window, [scrollspies[i].check]);
      _results.push(i++);
    }
    return _results;
  };
  _c.component('scrollspy', {
    defaults: {
      target: false,
      cls: 'scrollspy-inview',
      initcls: 'scrollspy-init-inview',
      topoffset: 0,
      leftoffset: 0,
      repeat: false,
      delay: 0
    },
    boot: function() {
      $doc.on('scrolling.clique.dom', _c.utils.debounce(checkScrollSpy, 150));
      $win.on('load resize orientationchange', _c.utils.debounce(checkScrollSpy, 150));
      return _c.ready(function(context) {
        return $('[data-scrollspy]', context).each(function() {
          var element, obj;
          element = $(this);
          if (!element.data('clique.data.scrollspy')) {
            obj = _c.scrollspy(element, _c.utils.options(element.attr('data-scrollspy')));
          }
        });
      });
    },
    init: function() {
      var $this, fn, togglecls;
      $this = this;
      togglecls = this.options.cls.split(/,/);
      fn = function() {
        var delayIdx, elements, toggleclsIdx;
        elements = $this.options.target ? $this.element.find($this.options.target) : $this.element;
        delayIdx = elements.length === 1 ? 1 : 0;
        toggleclsIdx = 0;
        return elements.each(function(idx) {
          var element, initinview, inview, inviewstate, toggle;
          element = $(this);
          inviewstate = element.data('inviewstate');
          inview = _c.utils.isInView(element, $this.options);
          toggle = element.data('cliqueScrollspyCls') || togglecls[toggleclsIdx].trim();
          if (inview && !inviewstate && !element.data('scrollspy-idle')) {
            if (!initinview) {
              element.addClass($this.options.initcls);
              $this.offset = element.offset();
              initinview = true;
              element.trigger('init.clique.scrollspy');
            }
            element.data('scrollspy-idle', setTimeout(function() {
              element.addClass('scrollspy-inview').toggleClass(toggle).width();
              element.trigger('inview.clique.scrollspy');
              element.data('scrollspy-idle', false);
              return element.data('inviewstate', true);
            }, $this.options.delay * delayIdx));
            delayIdx++;
          }
          if (!inview && inviewstate && $this.options.repeat) {
            if (element.data('scrollspy-idle')) {
              clearTimeout(element.data('scrollspy-idle'));
            }
            element.removeClass('scrollspy-inview').toggleClass(toggle);
            element.data('inviewstate', false);
            element.trigger('outview.clique.scrollspy');
          }
          toggleclsIdx = togglecls[toggleclsIdx + 1] ? toggleclsIdx + 1 : 0;
        });
      };
      fn();
      this.check = fn;
      return scrollspies.push(this);
    }
  });
  scrollspynavs = [];
  checkScrollSpyNavs = function() {
    var i, _results;
    i = 0;
    _results = [];
    while (i < scrollspynavs.length) {
      _c.support.requestAnimationFrame.apply(window, [scrollspynavs[i].check]);
      _results.push(i++);
    }
    return _results;
  };
  return _c.component('scrollspynav', {
    defaults: {
      cls: 'active',
      closest: false,
      topoffset: 0,
      leftoffset: 0,
      smoothscroll: false
    },
    boot: function() {
      $doc.on('scrolling.clique.dom', checkScrollSpyNavs);
      $win.on('resize orientationchange', _c.utils.debounce(checkScrollSpyNavs, 50));
      return _c.ready(function(context) {
        return $('[data-scrollspy-nav]', context).each(function() {
          var element, obj;
          element = $(this);
          if (!element.data('scrollspynav')) {
            obj = _c.scrollspynav(element, _c.utils.options(element.attr('data-scrollspy-nav')));
          }
        });
      });
    },
    init: function() {
      var $this, clsActive, clsClosest, fn, ids, links, targets;
      ids = [];
      links = this.find('a[href^=\'#\']').each(function() {
        return ids.push($(this).attr('href'));
      });
      targets = $(ids.join(','));
      clsActive = this.options.cls;
      clsClosest = this.options.closest || this.options.closest;
      $this = this;
      fn = function() {
        var i, inviews, navitems, scrollTop, target;
        inviews = [];
        i = 0;
        while (i < targets.length) {
          if (_c.utils.isInView(targets.eq(i), $this.options)) {
            inviews.push(targets.eq(i));
          }
          i++;
        }
        if (inviews.length) {
          scrollTop = $win.scrollTop();
          target = (function() {
            i = 0;
            while (i < inviews.length) {
              if (inviews[i].offset().top >= scrollTop) {
                return inviews[i];
              }
              i++;
            }
          })();
          if (!target) {
            return;
          }
          if ($this.options.closest) {
            links.closest(clsClosest).removeClass(clsActive);
            navitems = links.filter('a[href=\'#' + target.attr('id') + '\']').closest(clsClosest).addClass(clsActive);
          } else {
            navitems = links.removeClass(clsActive).filter('a[href=\'#' + target.attr('id') + '\']').addClass(clsActive);
          }
          return $this.element.trigger('inview.clique.scrollspynav', [target, navitems]);
        }
      };
      if (this.options.smoothscroll && _c.smoothScroll) {
        links.each(function() {
          return _c.smoothScroll(this, $this.options.smoothscroll);
        });
      }
      fn();
      this.element.data('scrollspynav', this);
      this.check = fn;
      return scrollspynavs.push(this);
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-toggle', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.toggle requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, toggles;
  $ = _c.$;
  toggles = [];
  return _c.component('toggle', {
    defaults: {
      target: false,
      cls: 'hidden',
      animation: false,
      duration: 400
    },
    boot: function() {
      return _c.ready(function(context) {
        $('[data-toggle]', context).each(function() {
          var ele, obj;
          ele = $(this);
          if (!ele.data('clique.data.toggle')) {
            obj = _c.toggle(ele, _c.utils.options(ele.attr('data-toggle')));
          }
        });
        return setTimeout(function() {
          return toggles.forEach(function(toggle) {
            return toggle.getToggles();
          });
        }, 0);
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.aria = this.options.cls.indexOf('hidden') !== -1;
      this.getToggles();
      this.on('click', function(e) {
        if ($this.element.is('a[href="#"]')) {
          e.preventDefault();
        }
        return $this.toggle();
      });
      return toggles.push(this);
    },
    toggle: function() {
      var $this, animations, evt;
      if (!this.totoggle.length) {
        return;
      }
      if (this.options.animation && _c.support.animation) {
        $this = this;
        animations = this.options.animation.split(',');
        if (animations.length === 1) {
          animations[1] = animations[0];
        }
        animations[0] = animations[0].trim();
        animations[1] = animations[1].trim();
        this.totoggle.css('animation-duration', this.options.duration + 'ms');
        if (this.totoggle.hasClass(this.options.cls)) {
          this.totoggle.toggleClass(this.options.cls);
          this.totoggle.each(function() {
            return _c.utils.animate(this, animations[0]).then(function() {
              $(this).css('animation-duration', '');
              return _c.utils.checkDisplay(this);
            });
          });
        } else {
          this.totoggle.each(function() {
            return _c.utils.animate(this, animations[1] + ' animation-reverse').then((function(_this) {
              return function() {
                $(_this).toggleClass($this.options.cls).css('animation-duration', '');
                return _c.utils.checkDisplay(_this);
              };
            })(this));
          });
        }
      } else {
        this.totoggle.toggleClass(this.options.cls);
        evt = _c.$.Event({
          type: 'toggle.clique',
          relatedTarget: this.element
        });
        this.totoggle.trigger(evt);
        _c.utils.checkDisplay(this.totoggle);
      }
      return this.updateAria();
    },
    getToggles: function() {
      this.totoggle = this.options.target ? $(this.options.target) : [];
      return this.updateAria();
    },
    updateAria: function() {
      if (this.aria && this.totoggle.length) {
        return this.totoggle.each(function() {
          return $(this).attr('aria-hidden', $(this).hasClass('hidden'));
        });
      }
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-alert', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.alert requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $;
  $ = _c.$;
  return _c.component('alert', {
    defaults: {
      fade: true,
      duration: 400,
      trigger: '.alert-close'
    },
    boot: function() {
      return _c.$html.on('click.alert.clique', '[data-alert]', function(e) {
        var ele, obj;
        ele = $(this);
        if (!ele.data('clique.data.alert')) {
          obj = _c.alert(ele, _c.utils.options(ele.attr('data-alert')));
          if ($(e.target).is(obj.options.trigger)) {
            e.preventDefault();
            return obj.close();
          }
        }
      });
    },
    init: function() {
      return this.on('click', this.options.trigger, (function(_this) {
        return function(e) {
          e.preventDefault();
          return _this.close();
        };
      })(this));
    },
    close: function() {
      var element, removeElement;
      element = this.trigger('close.clique.alert');
      removeElement = (function(_this) {
        return function() {
          return _this.trigger('closed.clique.alert').remove();
        };
      })(this);
      if (this.options.fade) {
        return element.css({
          overflow: 'hidden',
          'max-height': element.height()
        }).animate({
          height: 0,
          opacity: 0,
          'padding-top': 0,
          'padding-bottom': 0,
          'margin-top': 0,
          'margin-bottom': 0
        }, this.options.duration, removeElement);
      } else {
        return removeElement();
      }
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-button', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.button requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, _target;
  $ = _c.$;
  _target = '.btn, button';
  _c.component('buttonRadio', {
    defaults: {
      target: '.btn'
    },
    boot: function() {
      return _c.$html.on('click.buttonRadio.clique', '[data-button-radio]', function(e) {
        var ele, obj, target;
        ele = $(this);
        if (!ele.data('clique.data.buttonRadio')) {
          obj = _c.buttonRadio(ele, _c.utils.options(ele.attr('data-button-radio')));
          target = $(e.target);
          if (target.hasClass(obj.options.target) || target.is('button')) {
            return target.trigger('click');
          }
        }
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.find(_target).attr('aria-checked', 'false').filter('.active').attr('aria-checked', 'true');
      return this.on('click', _target, function(e) {
        var ele;
        ele = $(this);
        if (ele.is('a[href="#"]')) {
          e.preventDefault();
        }
        $this.find(_target).not(ele).removeClass('active').blur();
        ele.addClass('active');
        $this.find(_target).not(ele).attr('aria-checked', 'false');
        ele.attr('aria-checked', 'true');
        return $this.trigger('change.clique.btn', [ele]);
      });
    },
    getSelected: function() {
      return this.find('.active');
    }
  });
  _c.component('buttonCheckbox', {
    defaults: {
      target: '.btn'
    },
    boot: function() {
      return _c.$html.on('click.buttonCheckbox.clique', '[data-button-checkbox]', function(e) {
        var ele, obj, target;
        ele = $(this);
        if (!ele.data('clique.data.buttonCheckbox')) {
          obj = _c.buttonCheckbox(ele, _c.utils.options(ele.attr('data-button-checkbox')));
          target = $(e.target);
          if (target.hasClass(obj.options.target) || target.is('button')) {
            return target.trigger('click');
          }
        }
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.find(_target).attr('aria-checked', 'false').filter('.active').attr('aria-checked', 'true');
      return this.on('click', _target, function(e) {
        var ele;
        ele = $(this);
        if (ele.is('a[href="#"]')) {
          e.preventDefault();
        }
        ele.toggleClass('active').blur();
        ele.attr('aria-checked', ele.hasClass('active'));
        return $this.trigger('change.clique.btn', [ele]);
      });
    },
    getSelected: function() {
      return this.find('.active');
    }
  });
  return _c.component('button', {
    defaults: {},
    boot: function() {
      return _c.$html.on('click.btn.clique', '[data-button]', function(e) {
        var ele, obj;
        ele = $(this);
        if (!ele.data('clique.data.button')) {
          obj = _c.button(ele, _c.utils.options(ele.attr('data-button')));
          return ele.trigger('click');
        }
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.element.attr('aria-pressed', this.element.hasClass('active'));
      return this.on('click', function(e) {
        if ($this.element.is('a[href="#"]')) {
          e.preventDefault();
        }
        $this.toggle();
        return $this.trigger('change.clique.btn', [$this.element.blur().hasClass('active')]);
      });
    },
    toggle: function() {
      this.element.toggleClass('active');
      return this.element.attr('aria-pressed', this.element.hasClass('active'));
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-dropdown', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.dropdown requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, active, hoverIdle;
  $ = _c.$;
  active = false;
  hoverIdle = null;
  return _c.component('dropdown', {
    defaults: {
      mode: 'hover',
      remaintime: 800,
      justify: false,
      boundary: _c.$win,
      delay: 0
    },
    remainIdle: false,
    boot: function() {
      var triggerevent;
      triggerevent = _c.support.touch ? 'click' : 'mouseenter';
      return _c.$html.on(triggerevent + '.dropdown.clique', '[data-dropdown]', function(e) {
        var ele, obj;
        ele = $(this);
        if (!ele.data('clique.data.dropdown')) {
          obj = _c.dropdown(ele, _c.utils.options(ele.data('dropdown')));
          if (triggerevent === 'click' || triggerevent === 'mouseenter' && obj.options.mode === 'hover') {
            obj.element.trigger(triggerevent);
          }
          if (obj.element.find('.dropdown').length) {
            return e.preventDefault();
          }
        }
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.dropdown = this.find('.dropdown');
      this.centered = this.dropdown.hasClass('dropdown-center');
      this.justified = this.options.justify ? $(this.options.justify) : false;
      this.boundary = $(this.options.boundary);
      this.flipped = this.dropdown.hasClass('dropdown-flip');
      if (!this.boundary.length) {
        this.boundary = _c.$win;
      }
      this.element.attr('aria-haspopup', 'true');
      this.element.attr('aria-expanded', this.element.hasClass('open'));
      if (this.options.mode === 'click' || _c.support.touch) {
        this.on('click.clique.dropdown', function(e) {
          var $target;
          $target = $(e.target);
          if (!$target.parents('.dropdown').length) {
            if ($target.is('a[href=\'#\']') || $target.parent().is('a[href=\'#\']') || $this.dropdown.length && !$this.dropdown.is(':visible')) {
              e.preventDefault();
            }
            $target.blur();
          }
          if (!$this.element.hasClass('open')) {
            return $this.show();
          } else {
            if ($target.is('a:not(.js-prevent)') || $target.is('.dropdown-close') || !$this.dropdown.find(e.target).length) {
              return $this.hide();
            }
          }
        });
      } else {
        this.on('mouseenter', function(e) {
          if ($this.remainIdle) {
            clearTimeout($this.remainIdle);
          }
          if (hoverIdle) {
            clearTimeout(hoverIdle);
          }
          hoverIdle = setTimeout($this.show.bind($this), $this.options.delay);
        }).on('mouseleave', function() {
          if (hoverIdle) {
            clearTimeout(hoverIdle);
          }
          $this.remainIdle = setTimeout(function() {
            return $this.hide();
          }, $this.options.remaintime);
        }).on('click', function(e) {
          var $target;
          $target = $(e.target);
          if ($this.remainIdle) {
            clearTimeout($this.remainIdle);
          }
          if ($target.is('a[href=\'#\']') || $target.parent().is('a[href=\'#\']')) {
            e.preventDefault();
          }
          return $this.show();
        });
      }
    },
    show: function() {
      _c.$html.off('click.outer.dropdown');
      if (active && active[0] !== this.element[0]) {
        active.removeClass('open');
        active.attr('aria-expanded', 'false');
      }
      if (hoverIdle) {
        clearTimeout(hoverIdle);
      }
      this.checkDimensions();
      this.element.addClass('open');
      this.element.attr('aria-expanded', 'true');
      this.trigger('show.clique.dropdown', [this]);
      _c.utils.checkDisplay(this.dropdown, true);
      active = this.element;
      return this.registerOuterClick();
    },
    hide: function() {
      this.element.removeClass('open');
      this.remainIdle = false;
      this.element.attr('aria-expanded', 'false');
      this.trigger('hide.clique.dropdown', [this]);
      if (active && active[0] === this.element[0]) {
        active = false;
      }
    },
    registerOuterClick: function() {
      var $this;
      $this = this;
      _c.$html.off('click.outer.dropdown');
      return setTimeout((function() {
        return _c.$html.on('click.outer.dropdown', function(e) {
          var $target;
          if (hoverIdle) {
            clearTimeout(hoverIdle);
          }
          $target = $(e.target);
          if (active && active[0] === $this.element[0] && ($target.is('a:not(.js-prevent)') || $target.is('.dropdown-close') || !$this.dropdown.find(e.target).length)) {
            $this.hide();
            return _c.$html.off('click.outer.dropdown');
          }
        });
      }), 10);
    },
    checkDimensions: function() {
      var $this, boundaryoffset, boundarywidth, dropdown, jwidth, offset, right1, right2, width;
      if (!this.dropdown.length) {
        return;
      }
      if (this.justified && this.justified.length) {
        this.dropdown.css('min-width', '');
      }
      $this = this;
      dropdown = this.dropdown.css('margin-' + _c.langdirection, '');
      offset = dropdown.show().offset();
      width = dropdown.outerWidth();
      boundarywidth = this.boundary.width();
      boundaryoffset = this.boundary.offset() ? this.boundary.offset().left : 0;
      if (this.centered) {
        dropdown.css('margin-' + _c.langdirection, (parseFloat(width) / 2 - dropdown.parent().width() / 2) * -1);
        offset = dropdown.offset();
        if (width + offset.left > boundarywidth || offset.left < 0) {
          dropdown.css('margin-' + _c.langdirection, '');
          offset = dropdown.offset();
        }
      }
      if (this.justified && this.justified.length) {
        jwidth = this.justified.outerWidth();
        dropdown.css('min-width', jwidth);
        if (_c.langdirection === 'right') {
          right1 = boundarywidth - (this.justified.offset().left + jwidth);
          right2 = boundarywidth - (dropdown.offset().left + dropdown.outerWidth());
          dropdown.css('margin-right', right1 - right2);
        } else {
          dropdown.css('margin-left', this.justified.offset().left - offset.left);
        }
        offset = dropdown.offset();
      }
      if (width + (offset.left - boundaryoffset) > boundarywidth) {
        dropdown.addClass('dropdown-flip');
        offset = dropdown.offset();
      }
      if (offset.left - boundaryoffset < 0) {
        dropdown.addClass('dropdown-stack');
        if (dropdown.hasClass('dropdown-flip')) {
          if (!this.flipped) {
            dropdown.removeClass('dropdown-flip');
            offset = dropdown.offset();
            dropdown.addClass('dropdown-flip');
          }
          setTimeout(function() {
            if (dropdown.offset().left - boundaryoffset < 0 || !$this.flipped && dropdown.outerWidth() + (offset.left - boundaryoffset) < boundarywidth) {
              return dropdown.removeClass('dropdown-flip');
            }
          }, 0);
        }
        this.trigger('stack.clique.dropdown', [this]);
      }
      return dropdown.css('display', '');
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-form', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.form requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $;
  $ = _c.$;
  _c.component('checkbox', {
    boot: function() {
      return _c.on('ready', function(context) {
        return $('input[type="checkbox"]:not([data-switch])').each(function() {
          var ele;
          ele = $(this);
          if (!$(this).data('clique.data.checkbox')) {
            return _c.checkbox(ele);
          }
        });
      });
    },
    init: function() {
      if (!$(this.element).closest('.form-checkbox').length) {
        $(this.element).wrap("<span class='form-checkbox' />");
        $(this.element).after("<span />");
      }
      return this.triggerEvents();
    },
    triggerEvents: function() {
      return $(this.element).on('change', function(e) {
        if ($(this.element).is(':checked')) {
          return $(this.element).trigger('clique.checkbox.checked');
        } else {
          return $(this.element).trigger('clique.checkbox.unchecked');
        }
      });
    }
  });
  return _c.component('radio', {
    boot: function() {
      return _c.on('ready', function(context) {
        return $('input[type="radio"]').each(function() {
          var ele;
          ele = $(this);
          if (!$(this).data('clique.data.radio')) {
            return _c.radio(ele);
          }
        });
      });
    },
    init: function() {
      if (!$(this.element).closest('.form-radio').length) {
        $(this.element).wrap("<span class='form-radio' />");
        $(this.element).after("<span />");
      }
      return this.triggerEvents();
    },
    triggerEvents: function() {
      return $(this.element).on('change', function(e) {
        if ($(this.element).is(':checked')) {
          return $(this.element).trigger('clique.radio.checked');
        } else {
          return $(this.element).trigger('clique.radio.unchecked');
        }
      });
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-grid', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.grid requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, grids;
  $ = _c.$;
  grids = [];
  _c.component('rowMatchHeight', {
    defaults: {
      target: false,
      row: true
    },
    boot: function() {
      return _c.ready(function(context) {
        return $('[data-row-match]', context).each(function() {
          var grid, obj;
          grid = $(this);
          if (!grid.data('rowMatchHeight')) {
            obj = _c.rowMatchHeight(grid, _c.utils.options(grid.attr('data-row-match')));
          }
        });
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.columns = this.element.children();
      this.elements = this.options.target ? this.find(this.options.target) : this.columns;
      if (!this.columns.length) {
        return;
      }
      _c.$win.on('load resize orientationchange', (function() {
        var fn;
        fn = function() {
          return $this.match();
        };
        _c.$(function() {
          return fn();
        });
        return _c.utils.debounce(fn, 50);
      })());
      _c.$html.on('changed.clique.dom', function(e) {
        $this.columns = $this.element.children();
        $this.elements = $this.options.target ? $this.find($this.options.target) : $this.columns;
        return $this.match();
      });
      this.on('display.clique.check', (function(_this) {
        return function(e) {
          if (_this.element.is(':visible')) {
            return _this.match();
          }
        };
      })(this));
      return grids.push(this);
    },
    match: function() {
      var firstvisible, stacked;
      firstvisible = this.columns.filter(':visible:first');
      if (!firstvisible.length) {
        return;
      }
      stacked = Math.ceil(100 * parseFloat(firstvisible.css('width')) / parseFloat(firstvisible.parent().css('width'))) >= 100;
      if (stacked) {
        this.revert();
      } else {
        _c.utils.matchHeights(this.elements, this.options);
      }
      return this;
    },
    revert: function() {
      this.elements.css('min-height', '');
      return this;
    }
  });
  _c.component('rowMargin', {
    defaults: {
      cls: 'row-margin'
    },
    boot: function() {
      return _c.ready(function(context) {
        return $('[data-row-margin]', context).each(function() {
          var grid, obj;
          grid = $(this);
          if (!grid.data('rowMargin')) {
            obj = _c.rowMargin(grid, _c.utils.options(grid.attr('data-row-margin')));
          }
        });
      });
    },
    init: function() {
      var stackMargin;
      stackMargin = _c.stackMargin(this.element, this.options);
      return this.element.trigger('init.clique.grid');
    }
  });
  _c.utils.matchHeights = function(elements, options) {
    var matchHeights;
    elements = $(elements).css('min-height', '');
    options = _c.$.extend({
      row: true
    }, options);
    matchHeights = function(group) {
      var max;
      if (group.length < 2) {
        return;
      }
      max = 0;
      return group.each(function() {
        max = Math.max(max, $(this).outerHeight());
      }).each(function() {
        return $(this).css('min-height', max);
      });
    };
    if (options.row) {
      elements.first().width();
      return setTimeout(function() {
        var group, lastoffset;
        lastoffset = false;
        group = [];
        elements.each(function() {
          var ele, offset;
          ele = $(this);
          offset = ele.offset().top;
          if (offset !== lastoffset && group.length) {
            matchHeights($(group));
            group = [];
            offset = ele.offset().top;
          }
          group.push(ele);
          lastoffset = offset;
        });
        if (group.length) {
          return matchHeights($(group));
        }
      }, 0);
    } else {
      return matchHeights(elements);
    }
  };
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-modal', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.modal requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, active, setContent;
  $ = _c.$;
  setContent = function(content, modal) {
    if (!modal) {
      return;
    }
    if (typeof content === 'object') {
      content = (content instanceof jQuery ? content : $(content));
      if (content.parent().length) {
        modal.persist = content;
        modal.persist.data('modalPersistParent', content.parent());
      }
    } else {
      if (typeof content === 'string' || typeof content === 'number') {
        content = $('<div></div>').html(content);
      } else {
        content = $('<div></div>').html('Clique.modal Error : Unsupported data type : ' + typeof content);
      }
    }
    content.appendTo(modal.element.find('.modal-dialog'));
    return modal;
  };
  active = false;
  _c.component('modal', {
    defaults: {
      keyboard: true,
      bgclose: true,
      minScrollHeight: 150,
      center: false
    },
    scrollable: false,
    transition: false,
    init: function() {
      var $this;
      $this = this;
      this.transition = _c.support.transition;
      this.paddingdir = 'padding-' + (_c.langdirection === 'left' ? 'right' : 'left');
      this.dialog = this.find('.modal-dialog');
      this.element.attr('aria-hidden', this.element.hasClass('open'));
      return this.on('click', '.modal-close', function(e) {
        e.preventDefault();
        return $this.hide();
      }).on('click', function(e) {
        var target;
        target = $(e.target);
        if (target[0] === $this.element[0] && $this.options.bgclose) {
          return $this.hide();
        }
      });
    },
    toggle: function() {
      return this[(this.isActive() ? 'hide' : 'show')]();
    },
    show: function() {
      var $this;
      $this = this;
      if (this.isActive()) {
        return;
      }
      if (active) {
        active.hide(true);
      }
      this.element.removeClass('open').show();
      this.resize();
      active = this;
      _c.$html.addClass('modal-page').height();
      this.element.addClass('open');
      this.element.attr('aria-hidden', 'false');
      this.element.trigger('show.clique.modal');
      _c.utils.checkDisplay(this.dialog, true);
      return this;
    },
    hide: function(force) {
      var $this;
      if (!this.isActive()) {
        return;
      }
      if (!force && _c.support.transition) {
        $this = this;
        this.one(_c.support.transition.end, function() {
          return $this._hide();
        }).removeClass('open');
      } else {
        this._hide();
      }
      return this;
    },
    resize: function() {
      var bodywidth, dh, pad;
      bodywidth = _c.$body.width();
      this.scrollbarwidth = window.innerWidth - bodywidth;
      _c.$body.css(this.paddingdir, this.scrollbarwidth);
      this.element.css('overflow-y', (this.scrollbarwidth ? 'scroll' : 'auto'));
      if (!this.updateScrollable() && this.options.center) {
        dh = this.dialog.outerHeight();
        pad = parseInt(this.dialog.css('margin-top'), 10) + parseInt(this.dialog.css('margin-bottom'), 10);
        if (dh + pad < window.innerHeight) {
          return this.dialog.css({
            top: window.innerHeight / 2 - dh / 2 - pad
          });
        } else {
          return this.dialog.css({
            top: ''
          });
        }
      }
    },
    updateScrollable: function() {
      var dh, h, offset, scrollable, wh;
      scrollable = this.dialog.find('.overflow-container:visible:first');
      if (scrollable.length) {
        scrollable.css('height', 0);
        offset = Math.abs(parseInt(this.dialog.css('margin-top'), 10));
        dh = this.dialog.outerHeight();
        wh = window.innerHeight;
        h = wh - 2 * (offset < 20 ? 20 : offset) - dh;
        scrollable.css('height', (h < this.options.minScrollHeight ? '' : h));
        return true;
      }
      return false;
    },
    _hide: function() {
      this.element.hide().removeClass('open');
      this.element.attr('aria-hidden', 'true');
      _c.$html.removeClass('modal-page');
      _c.$body.css(this.paddingdir, '');
      if (active === this) {
        active = false;
      }
      return this.trigger('hide.clique.modal');
    },
    isActive: function() {
      return active === this;
    }
  });
  _c.component('modalTrigger', {
    boot: function() {
      _c.$html.on('click.modal.clique', '[data-modal]', function(e) {
        var ele, modal;
        ele = $(this);
        if (ele.is('a')) {
          e.preventDefault();
        }
        if (!ele.data('clique.data.modalTrigger')) {
          modal = _c.modalTrigger(ele, _c.utils.options(ele.attr('data-modal')));
          return modal.show();
        }
      });
      _c.$html.on('keydown.modal.clique', function(e) {
        if (active && e.keyCode === 27 && active.options.keyboard) {
          e.preventDefault();
          return active.hide();
        }
      });
      return _c.$win.on('resize orientationchange', _c.utils.debounce(function() {
        if (active) {
          return active.resize();
        }
      }, 150));
    },
    init: function() {
      var $this;
      $this = this;
      this.options = _c.$.extend({
        target: ($this.element.is('a') ? $this.element.attr('href') : false)
      }, this.options);
      this.modal = _c.modal(this.options.target, this.options);
      this.on('click', function(e) {
        e.preventDefault();
        return $this.show();
      });
      return this.proxy(this.modal, 'show hide isActive');
    }
  });
  _c.modal.dialog = function(content, options) {
    var modal;
    modal = _c.modal($(_c.modal.dialog.template).appendTo('body'), options);
    modal.on('hide.clique.modal', function() {
      if (modal.persist) {
        modal.persist.appendTo(modal.persist.data('modalPersistParent'));
        modal.persist = false;
      }
      return modal.element.remove();
    });
    setContent(content, modal);
    return modal;
  };
  _c.modal.dialog.template = '<div class="modal"><div class="modal-dialog" style="min-height :0;"></div></div>';
  _c.modal.alert = function(content, options) {
    return _c.modal.dialog(['<div class="margin modal-content">' + String(content) + '</div>', '<div class="modal-footer text-right"><button class="button button-primary modal-close">Ok</button></div>'].join(''), _c.$.extend({
      bgclose: false,
      keyboard: false
    }, options)).show();
  };
  _c.modal.confirm = function(content, onconfirm, options) {
    var modal;
    onconfirm = (_c.$.isFunction(onconfirm) ? onconfirm : function() {});
    modal = _c.modal.dialog(['<div class="margin modal-content">' + String(content) + '</div>', '<div class="modal-footer text-right"><button class="button button-primary js-modal-confirm">Ok</button> <button class="button modal-close">Cancel</button></div>'].join(''), _c.$.extend({
      bgclose: false,
      keyboard: false
    }, options));
    modal.element.find('.js-modal-confirm').on('click', function() {
      onconfirm();
      return modal.hide();
    });
    return modal.show();
  };
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-nav', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.nav requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, getHeight;
  $ = _c.$;
  getHeight = function(ele) {
    var $ele, height, tmp;
    $ele = $(ele);
    height = 'auto';
    if ($ele.is(':visible')) {
      height = $ele.outerHeight();
    } else {
      tmp = {
        position: $ele.css('position'),
        visibility: $ele.css('visibility'),
        display: $ele.css('display')
      };
      height = $ele.css({
        position: 'absolute',
        visibility: 'hidden',
        display: 'block'
      }).outerHeight();
      $ele.css(tmp);
    }
    return height;
  };
  return _c.component('nav', {
    defaults: {
      toggle: '>li.parent > a[href=\'#\']',
      lists: '>li.parent > ul',
      multiple: false
    },
    boot: function() {
      return _c.ready(function(context) {
        return $('[data-nav]', context).each(function() {
          var nav, obj;
          nav = $(this);
          if (!nav.data('clique.data.nav')) {
            obj = _c.nav(nav, _c.utils.options(nav.attr('data-nav')));
          }
        });
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.on('click.clique.nav', this.options.toggle, function(e) {
        var ele;
        e.preventDefault();
        ele = $(this);
        return $this.open((ele.parent()[0] === $this.element[0] ? ele : ele.parent('li')));
      });
      return this.find(this.options.lists).each(function() {
        var $ele, active, parent;
        $ele = $(this);
        parent = $ele.parent();
        active = parent.hasClass('active');
        $ele.wrap('<div style="overflow :hidden;height :0;position :relative;"></div>');
        parent.data('list-container', $ele.parent());
        parent.attr('aria-expanded', parent.hasClass('open'));
        if (active) {
          return $this.open(parent, true);
        }
      });
    },
    open: function(li, noAnimation) {
      var $li, $this, element;
      $this = this;
      element = this.element;
      $li = $(li);
      if (!this.options.multiple) {
        element.children('.open').not(li).each(function() {
          var ele;
          ele = $(this);
          if (ele.data('list-container')) {
            return ele.data('list-container').stop().animate({
              height: 0
            }, function() {
              return $(this).parent().removeClass('open');
            });
          }
        });
      }
      $li.toggleClass('open');
      $li.attr('aria-expanded', $li.hasClass('open'));
      if ($li.data('list-container')) {
        if (noAnimation) {
          $li.data('list-container').stop().height(($li.hasClass('open') ? 'auto' : 0));
          return this.trigger('display.clique.check');
        } else {
          return $li.data('list-container').stop().animate({
            height: $li.hasClass('open') ? getHeight($li.data('list-container').find('ul:first')) : 0
          }, function() {
            return $this.trigger('display.clique.check');
          });
        }
      }
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-switcher', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.switcher requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $, Animations, coreAnimation;
  $ = _c.$;
  coreAnimation = function(cls, current, next) {
    var clsIn, clsOut, d, release;
    d = _c.$.Deferred();
    clsIn = cls;
    clsOut = cls;
    if (next[0] === current[0]) {
      d.resolve();
      return d.promise();
    }
    if (typeof cls === 'object') {
      clsIn = cls[0];
      clsOut = cls[1] || cls[0];
    }
    release = function() {
      if (current) {
        current.hide().removeClass('active ' + clsOut + ' animation-reverse');
      }
      return next.addClass(clsIn).one(_c.support.animation.end, (function(_this) {
        return function() {
          next.removeClass('' + clsIn + '').css({
            opacity: '',
            display: ''
          });
          d.resolve();
          if (current) {
            return current.css({
              opacity: '',
              display: ''
            });
          }
        };
      })(this)).show();
    };
    next.css('animation-duration', this.options.duration + 'ms');
    if (current && current.length) {
      current.css('animation-duration', this.options.duration + 'ms');
      current.css('display', 'none').addClass(clsOut + ' animation-reverse').one(_c.support.animation.end, (function(_this) {
        return function() {
          return release();
        };
      })(this)).css('display', '');
    } else {
      next.addClass('active');
      release();
    }
    return d.promise();
  };
  _c.component('switcher', {
    defaults: {
      connect: false,
      toggle: '>*',
      active: 0,
      animation: false,
      duration: 200
    },
    animating: false,
    boot: function() {
      return _c.ready(function(context) {
        return $('[data-switcher]', context).each(function() {
          var obj, switcher;
          switcher = $(this);
          if (!switcher.data('clique.data.switcher')) {
            obj = _c.switcher(switcher, _c.utils.options(switcher.attr('data-switcher')));
          }
        });
      });
    },
    init: function() {
      var $this, active, toggles;
      $this = this;
      this.on('click.clique.switcher', this.options.toggle, function(e) {
        e.preventDefault();
        return $this.show(this);
      });
      if (this.options.connect) {
        this.connect = $(this.options.connect);
        this.connect.find('.active').removeClass('.active');
        if (this.connect.length) {
          this.connect.children().attr('aria-hidden', 'true');
          this.connect.on('click', '[data-switcher-item]', function(e) {
            var item;
            e.preventDefault();
            item = $(this).attr('data-switcher-item');
            if ($this.index === item) {
              return;
            }
            switch (item) {
              case 'next':
              case 'previous':
                return $this.show($this.index + (item === 'next' ? 1 : -1));
              default:
                return $this.show(parseInt(item, 10));
            }
          }).on('swipeRight swipeLeft', function(e) {
            e.preventDefault();
            return $this.show($this.index + (e.type === 'swipeLeft' ? 1 : -1));
          });
        }
        toggles = this.find(this.options.toggle);
        active = toggles.filter('.active');
        if (active.length) {
          this.show(active, false);
        } else {
          if (this.options.active === false) {
            return;
          }
          active = toggles.eq(this.options.active);
          this.show((active.length ? active : toggles.eq(0)), false);
        }
        toggles.not(active).attr('aria-expanded', 'false');
        active.attr('aria-expanded', 'true');
        return this.on('changed.clique.dom', function() {
          $this.connect = $($this.options.connect);
        });
      }
    },
    show: function(tab, animate) {
      var $this, active, animation, toggles;
      if (this.animating) {
        return;
      }
      if (isNaN(tab)) {
        tab = $(tab);
      } else {
        toggles = this.find(this.options.toggle);
        tab = (tab < 0 ? toggles.length - 1 : tab);
        tab = toggles.eq((toggles[tab] ? tab : 0));
      }
      $this = this;
      toggles = this.find(this.options.toggle);
      active = $(tab);
      animation = Animations[this.options.animation] || function(current, next) {
        var anim;
        if (!$this.options.animation) {
          return Animations.none.apply($this);
        }
        anim = $this.options.animation.split(',');
        if (anim.length === 1) {
          anim[1] = anim[0];
        }
        anim[0] = anim[0].trim();
        anim[1] = anim[1].trim();
        return coreAnimation.apply($this, [anim, current, next]);
      };
      if (animate === false || !_c.support.animation) {
        animation = Animations.none;
      }
      if (active.hasClass('disabled')) {
        return;
      }
      toggles.attr('aria-expanded', 'false');
      active.attr('aria-expanded', 'true');
      toggles.filter('.active').removeClass('active');
      active.addClass('active');
      if (this.options.connect && this.connect.length) {
        this.index = this.find(this.options.toggle).index(active);
        if (this.index === -1) {
          this.index = 0;
        }
        this.connect.each(function() {
          var children, container, current, next;
          container = $(this);
          children = $(container.children());
          current = $(children.filter('.active'));
          next = $(children.eq($this.index));
          $this.animating = true;
          return animation.apply($this, [current, next]).then(function() {
            current.removeClass('active');
            next.addClass('active');
            current.attr('aria-hidden', 'true');
            next.attr('aria-hidden', 'false');
            _c.utils.checkDisplay(next, true);
            $this.animating = false;
          });
        });
      }
      return this.trigger('show.clique.switcher', [active]);
    }
  });
  Animations = {
    none: function() {
      var d;
      d = _c.$.Deferred();
      d.resolve();
      return d.promise();
    },
    fade: function(current, next) {
      return coreAnimation.apply(this, ['animation-fade', current, next]);
    },
    'slide-bottom': function(current, next) {
      return coreAnimation.apply(this, ['animation-slide-bottom', current, next]);
    },
    'slide-top': function(current, next) {
      return coreAnimation.apply(this, ['animation-slide-top', current, next]);
    },
    'slide-vertical': function(current, next, dir) {
      var anim;
      anim = ['animation-slide-top', 'animation-slide-bottom'];
      if (current && current.index() > next.index()) {
        anim.reverse();
      }
      return coreAnimation.apply(this, [anim, current, next]);
    },
    'slide-left': function(current, next) {
      return coreAnimation.apply(this, ['animation-slide-left', current, next]);
    },
    'slide-right': function(current, next) {
      return coreAnimation.apply(this, ['animation-slide-right', current, next]);
    },
    'slide-horizontal': function(current, next, dir) {
      var anim;
      anim = ['animation-slide-right', 'animation-slide-left'];
      if (current && current.index() > next.index()) {
        anim.reverse();
      }
      return coreAnimation.apply(this, [anim, current, next]);
    },
    scale: function(current, next) {
      return coreAnimation.apply(this, ['animation-scale-up', current, next]);
    }
  };
  _c.switcher.animations = Animations;
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-select', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.select requires Clique.core');
  }
  if (!window.Clique.dropdown) {
    throw new Error('Clique.select requires the Clique.dropdown component');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $;
  $ = _c.$;
  _c.component('select', {
    defaults: {
      inheritClasses: true
    },
    boot: function() {
      return _c.on('ready', function(context) {
        return $('[data-select]', context).each(function() {
          var ele, obj;
          ele = $(this);
          if (!ele.is('select')) {
            return ele.find('select').each(function() {
              var obj;
              if (!ele.data('clique.data.select')) {
                obj = _c.select(ele);
              }
            });
          } else {
            if (!ele.data('clique.data.select')) {
              obj = _c.select(ele);
            }
          }
        });
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.element.on('clique.select.change', function(e, idx, obj) {
        return $this.updateSelect(idx, obj);
      });
      this.selectOptions = [];
      this.element.children('option').each(function(i) {
        return $this.selectOptions.push({
          text: $(this).text(),
          value: $(this).val()
        });
      });
      this.template();
      this.bindSelect();
      return setTimeout(function() {
        return $this.select.find('.nav-dropdown li:first-child a').trigger('click');
      }, 0);
    },
    template: function() {
      var $this, classes, cls, firstOption, width;
      cls = [];
      if (this.options.inheritClasses && this.element.attr('class')) {
        classes = this.element.attr('class').split(' ');
        $.each(classes, function(i) {
          return cls.push(classes[i]);
        });
      }
      cls.push('select');
      width = this.element.width() + 23;
      this.select = $('<div class="' + cls.join(' ') + '" data-dropdown="{mode:\'click\'}" style="width:' + width + 'px;" />');
      firstOption = this.element.children('option').first();
      this.select.append($('<a href="#" class="select-link"></a>'));
      this.select.append($('<div class="dropdown dropdown-scrollable"><ul class="nav nav-dropdown nav-side" /></div>'));
      $this = this;
      $.each(this.selectOptions, function(i, v) {
        var option;
        option = $('<li><a href="#">' + v.text + '</a></li>');
        return $this.select.find('.nav-dropdown').append(option);
      });
      this.element.before(this.select);
      return this.element.hide();
    },
    bindSelect: function() {
      var $this;
      $this = this;
      return this.select.on('click', '.nav-dropdown a', function(e) {
        var idx, obj, option;
        e.preventDefault();
        idx = $(this).parent('li').index();
        option = $this.selectOptions[idx];
        obj = {
          value: option.value,
          text: option.text
        };
        return $this.element.trigger('clique.select.change', [idx, obj]);
      });
    },
    updateSelect: function(idx, obj) {
      var li;
      this.select.find('.nav-dropdown li').removeClass('active');
      li = this.select.find('.nav-dropdown li').eq(idx);
      li.addClass('active');
      this.select.children('.select-link').text(obj.text);
      this.element.val(obj.value);
      return this.trigger('change');
    }
  });
  return _c.select;
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-tab', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.tab requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $;
  $ = _c.$;
  return _c.component('tab', {
    defaults: {
      target: '> li:not(.tab-responsive, .disabled)',
      connect: false,
      active: 0,
      animation: false,
      duration: 200
    },
    boot: function() {
      return _c.ready(function(context) {
        return $('[data-tab]', context).each(function() {
          var obj, tab;
          tab = $(this);
          if (!tab.data('clique.data.tab')) {
            obj = _c.tab(tab, _c.utils.options(tab.attr('data-tab')));
          }
        });
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.on('click.clique.tab', this.options.target, function(e) {
        var current;
        e.preventDefault();
        if ($this.switcher && $this.switcher.animating) {
          return;
        }
        current = $this.find($this.options.target).not(this);
        current.removeClass('active').blur();
        $this.trigger('change.clique.tab', [$(this).addClass('active')]);
        if (!$this.options.connect) {
          current.attr('aria-expanded', 'false');
          return $(this).attr('aria-expanded', 'true');
        }
      });
      if (this.options.connect) {
        this.connect = $(this.options.connect);
      }
      this.responsivetab = $('<li class="tab-responsive active"><a></a></li>').append('<div class="dropdown dropdown-small"><ul class="nav nav-dropdown"></ul><div>');
      this.responsivetab.dropdown = this.responsivetab.find('.dropdown');
      this.responsivetab.lst = this.responsivetab.dropdown.find('ul');
      this.responsivetab.caption = this.responsivetab.find('a:first');
      if (this.element.hasClass('tab-bottom')) {
        this.responsivetab.dropdown.addClass('dropdown-up');
      }
      this.responsivetab.lst.on('click.clique.tab', 'a', function(e) {
        var link;
        e.preventDefault();
        e.stopPropagation();
        link = $(this);
        return $this.element.children(':not(.tab-responsive)').eq(link.data('index')).trigger('click');
      });
      this.on('show.clique.switcher change.clique.tab', function(e, tab) {
        return $this.responsivetab.caption.html(tab.text());
      });
      this.element.append(this.responsivetab);
      if (this.options.connect) {
        this.switcher = _c.switcher(this.element, {
          toggle: '> li:not(.tab-responsive)',
          connect: this.options.connect,
          active: this.options.active,
          animation: this.options.animation,
          duration: this.options.duration
        });
      }
      _c.dropdown(this.responsivetab, {
        mode: 'click'
      });
      $this.trigger('change.clique.tab', [this.element.find(this.options.target).filter('.active')]);
      this.check();
      _c.$win.on('resize orientationchange', _c.utils.debounce(function() {
        if ($this.element.is(':visible')) {
          return $this.check();
        }
      }, 100));
      return this.on('display.clique.check', function() {
        if ($this.element.is(':visible')) {
          return $this.check();
        }
      });
    },
    check: function() {
      var children, doresponsive, i, item, link, top;
      children = this.element.children(':not(.tab-responsive)').removeClass('hidden');
      if (!children.length) {
        return;
      }
      top = children.eq(0).offset().top + Math.ceil(children.eq(0).height() / 2);
      doresponsive = false;
      this.responsivetab.lst.empty();
      children.each(function() {
        if ($(this).offset().top > top) {
          doresponsive = true;
        }
      });
      if (doresponsive) {
        i = 0;
        while (i < children.length) {
          item = $(children.eq(i));
          link = item.find('a');
          if (item.css('float') !== 'none' && !item.attr('dropdown')) {
            item.addClass('hidden');
            if (!item.hasClass('disabled')) {
              this.responsivetab.lst.append('<li><a href="' + link.attr('href') + '" data-index="' + i + '">' + link.html() + '</a></li>');
            }
          }
          i++;
        }
      }
      return this.responsivetab[(this.responsivetab.lst.children().length ? 'removeClass' : 'addClass')]('hidden');
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-cover', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.cover requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $;
  $ = _c.$;
  return _c.component('cover', {
    defaults: {
      automute: true
    },
    boot: function() {
      return _c.ready(function(context) {
        return $('[data-cover]', context).each(function() {
          var ele, obj;
          ele = $(this);
          if (!ele.data('clique.data.cover')) {
            obj = _c.cover(ele, _c.utils.options(ele.attr('data-cover')));
          }
        });
      });
    },
    init: function() {
      var src;
      this.parent = this.element.parent();
      _c.$win.on('load resize orientationchange', _c.utils.debounce((function(_this) {
        return function() {
          return _this.check();
        };
      })(this), 100));
      this.on('display.clique.check', (function(_this) {
        return function(e) {
          if (_this.is(':visible')) {
            return _this.check();
          }
        };
      })(this));
      this.check();
      if (this.element.is('iframe') && this.options.automute) {
        src = this.element.attr('src');
        return this.element.attr('src', '').on('load', function() {
          return this.contentWindow.postMessage('{ "event" : "command", "func" : "mute", "method" :"setVolume", "value" :0}', '*');
        }).attr('src', [src, src.indexOf('?') > -1 ? '&' : '?', 'enablejsapi=1&api=1'].join(''));
      }
    },
    check: function() {
      var h, height, w, width;
      this.element.css({
        width: '',
        height: ''
      });
      this.dimension = {
        w: this.element.width(),
        h: this.element.height()
      };
      if (this.element.attr('width') && !isNaN(this.element.attr('width'))) {
        this.dimension.w = this.element.attr('width');
      }
      if (this.element.attr('height') && !isNaN(this.element.attr('height'))) {
        this.dimension.h = this.element.attr('height');
      }
      this.ratio = this.dimension.w / this.dimension.h;
      w = this.parent.width();
      h = this.parent.height();
      if (w / this.ratio < h) {
        width = Math.ceil(h * this.ratio);
        height = h;
      } else {
        width = w;
        height = Math.ceil(w / this.ratio);
      }
      return this.element.css({
        width: width,
        height: height
      });
    }
  });
});

(function(addon) {
  if (typeof define === 'function' && define.amd) {
    define('clique-form.password', ['clique'], function() {
      return addon(Clique);
    });
  }
  if (!window.Clique) {
    throw new Error('Clique.form.password requires Clique.core');
  }
  if (window.Clique) {
    addon(Clique);
  }
})(function(_c) {
  var $;
  $ = _c.$;
  _c.component('formPassword', {
    defaults: {
      lblShow: 'Show',
      lblHide: 'Hide'
    },
    boot: function() {
      return _c.$html.on('click.formpassword.clique', '[data-form-password]', function(e) {
        var ele, obj;
        ele = _c.$(this);
        if (!ele.data('clique.data.formPassword')) {
          e.preventDefault();
          obj = _c.formPassword(ele, _c.utils.options(ele.attr('data-form-password')));
          return ele.trigger('click');
        }
      });
    },
    init: function() {
      var $this;
      $this = this;
      this.on('click', (function(_this) {
        return function(e) {
          var type;
          e.preventDefault();
          if (_this.input.length) {
            type = _this.input.attr('type');
            _this.input.attr('type', (type === 'text' ? 'password' : 'text'));
            return _this.element.text(_this.options[(type === 'text' ? 'lblShow' : 'lblHide')]);
          }
        };
      })(this));
      this.input = (this.element.next('input').length ? this.element.next('input') : this.element.prev('input'));
      this.element.text(this.options[(this.input.is('[type=\'password\']') ? 'lblShow' : 'lblHide')]);
      return this.element.data('formPassword', this);
    }
  });
  return _c.formPassword;
});
